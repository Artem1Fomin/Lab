package ru.mirea.lab1.ex5;

public class Ex5 {
    public static void main(String[] args) {
        for (String el : args)
            System.out.print(el + " ");
    }
}
