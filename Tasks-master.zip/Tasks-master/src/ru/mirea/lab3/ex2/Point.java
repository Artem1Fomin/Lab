package ru.mirea.lab3.ex2;

public class Point {
    protected int x;
    protected int y;

    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }


    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }
}
