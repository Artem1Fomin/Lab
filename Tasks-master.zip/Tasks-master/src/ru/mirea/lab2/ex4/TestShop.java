package ru.mirea.lab2.ex4;

public class TestShop {
    public static void main(String[] args) {
        Shop s1 = new Shop();
        s1.addComp();
        s1.searchComp();
        s1.delComp();
        s1.searchComp();
    }
}
