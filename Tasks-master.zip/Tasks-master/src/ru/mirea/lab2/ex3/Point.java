package ru.mirea.lab2.ex3;

public class Point{
    protected int x;
    protected int y;

    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
